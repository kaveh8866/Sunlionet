﻿#!/usr/bin/env sh
set -eu
mode="${1:-inside}"
bin="shadownet-${mode}"
src="./${bin}"
dst="/usr/local/bin/${bin}"
install -m 0755 "$src" "$dst"
mkdir -p /etc/shadownet
if [ -f "./${bin}.service" ]; then
  install -m 0644 "./${bin}.service" "/etc/systemd/system/${bin}.service"
  systemctl daemon-reload || true
fi
printf "%s\n" "installed ${dst}"